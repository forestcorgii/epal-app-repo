<template>
  <div>
    <NuxtLink to="/hello">Hello</NuxtLink>
  <Tutorial/>
    </div>
</template>

<script>
export default {}
</script>
