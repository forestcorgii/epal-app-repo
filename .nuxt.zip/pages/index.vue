<template>
  <div>
    <NuxtLink to="/hello">Helllllo</NuxtLink>
  <Tutorial/>
    </div>
</template>

<script>
export default {}
</script>
